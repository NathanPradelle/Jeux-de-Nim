from gameMain import game, settings, fltica, theme, text




def showMainMenu():
    #fltica.animated_image(0, 0, 600, 338,  'images/explosion.gif', ancrage='nw')
    fltica.image(settings['sizex']/2, settings['sizey']/8, theme[settings['theme']]['gameName'])
    buttonList = []
    buttonList.append(fltica.Button(theme[settings['theme']]['buttonPosx'], settings['sizey']/2.65, text[settings['lang']]['Play'], game, color=theme[settings['theme']]['fontColor'],font=theme[settings['theme']]['font'], ancrage=theme[settings['theme']]['buttonAnc'], size=18, hoverColor=theme[settings['theme']]['buttonHoverColor'])) 
    buttonList.append(fltica.Button(theme[settings['theme']]['buttonPosx'], settings['sizey']/1.6, text[settings['lang']]['Quit'], exit, color=theme[settings['theme']]['fontColor'], font=theme[settings['theme']]['font'],ancrage=theme[settings['theme']]['buttonAnc'], size=18, hoverColor=theme[settings['theme']]['buttonHoverColor'])) 
    buttonList.append(fltica.Button(theme[settings['theme']]['buttonPosx'], settings['sizey']/2.0, text[settings['lang']]['Settings'], settingsMenu, color=theme[settings['theme']]['fontColor'], font=theme[settings['theme']]['font'],ancrage=theme[settings['theme']]['buttonAnc'], size=18, hoverColor=theme[settings['theme']]['buttonHoverColor']))
    if theme[settings['theme']]['buttonBg']:
        for button in buttonList:
            button.setBgImg(theme[settings['theme']]['buttonBg'], theme[settings['theme']]['buttonBgOn'], 300, 600, 60)
    return buttonList
    

def updateMenu(buttonList):
    while settings['updateValue']:
        ev = fltica.donne_ev()
        tev = fltica.type_ev(ev)
        fltica.mise_a_jour()
        for elem in buttonList :
            elem.update(tev)
        if tev == 'Touche' or tev == 'Quitte':
            if fltica.touche_pressee('Escape') or tev == 'Quitte':
                quit()
    settings['updateValue'] = 1


def createWindow():
    fltica.cree_fenetre(settings['sizex'],settings['sizey'])
    #fltica.__canevas.root.configure(cursor="dotbox blue")
    
    fltica.__canevas.root.iconbitmap('images/cigle-Eiffel.ico')
    fltica.__canevas.root.resizable(False, False)
    fltica.__canevas.root.title('Jeux de Nim')
    if 'Minecraft' in fltica.tk.font.families():
        theme['Minecraft']['font'] = 'Minecraft'
    else:
        print(text[settings['lang']]['missingFont'])
    fltica.image(0,0,theme[settings['theme']]['background'],settings['sizex'],settings['sizey'],'nw')
    fltica.texte(0,0,'ver dev-161221-0','#505050',police=theme[settings['theme']]['font'], taille=15)



def settingsMenu():
    settings['theme'] = 'Minecraft' if settings['theme'] == 'Allumette' else 'Allumette'
    settings['lang'] = 'eng' if settings['lang'] == 'fr' else 'jp'
    resetWindow()

    # Reset everything
def resetWindow():
    fltica.attente(0.1)
    try:
        fltica.__canevas.canvas.after_cancel(fltica.after_id)
    except AttributeError:
        pass
    fltica.ferme_fenetre()
    settings['updateValue'] = 0
    createWindow()

if __name__ == '__main__':
    createWindow()
    while True:
        buttonList = showMainMenu()
        updateMenu(buttonList,)