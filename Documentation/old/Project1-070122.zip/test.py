from tkinter import E
import json
import fltica
from playsound import playsound
from threading import Thread


fltica.cree_fenetre(800,0o0600)

class Button:
    def __init__(self, posx, posy, text, lenght, function, font="Helvetica", size=24):
        """
        Makes a button using position, text and lenght of the text
        uses the class unique object identifier
        """
        self.isHovered = False
        self.posx, self.posy, self.text, self.font, self.size = posx, posy, text, font, size
        self.func = function
        self.lenght = lenght+15
        self.pulse = 0
        self.pulseBigger = True
        fltica.texte(self.posx, self.posy, self.text, ancrage='center', police=self.font, taille=self.size, tag='a'+str(id(self)))
        
    def update(self, tev):
        if ((fltica.abscisse_souris() < self.posx+self.lenght and fltica.abscisse_souris() > self.posx-self.lenght) and 
        (fltica.ordonnee_souris() < self.posy+40 and fltica.ordonnee_souris() > self.posy-10)):

            if tev == 'ClicGauche':
                self.func()
            self.isHovered = True
            fltica.efface('a'+str(id(self)))
            fltica.texte(self.posx, self.posy, self.text,'red' ,ancrage='center', police=self.font, taille=self.size+self.pulse, tag='a'+str(id(self))) # 'a'+ is requiered for fltk 
            if self.pulseBigger :
                self.pulse += 1
                if self.pulse == 6:
                    self.pulseBigger = False
            else:
                self.pulse -= 1
                if self.pulse == 0:
                    self.pulseBigger = True

        elif self.isHovered:
            self.isHovered = False
            fltica.efface('a'+str(id(self)))
            fltica.texte(self.posx, self.posy, self.text,ancrage='center', police=self.font, taille=self.size, tag='a'+str(id(self)))

playerName = "Steve"
SteveWins = 5
SteveColor = "Blue"
SteveAvatar = 2
SteveMatch = 23
SteveTotalPlay = 6

print(fltica.taille_texte('Player'))

data = {}
data['Steve'] = {'SteveWins':SteveWins, 'SteveColor':SteveColor, 'SteveAvatar':SteveAvatar, 'SteveMatch':SteveMatch, 'SteveTotalPlay':SteveTotalPlay}
#data = {'Steve':{'SteveWins':SteveWins, 'SteveColor':SteveColor, 'SteveAvatar':SteveAvatar, 'SteveMatch':SteveMatch, 'SteveTotalPlay':SteveTotalPlay}}
jsondump = json.dumps(data)
jsonobject = json.loads(jsondump)
print('Steve' in jsonobject)

with open('save.json', 'w', encoding='utf-8') as f:
    json.dump(data, f, ensure_ascii=False, indent=4)

def playTest():
    Thread(target=playsound, args=('sounds/explode1.mp3',)).start()

bouton = Button(100, 100, 'test', 0, playTest)
while True:
    ev = fltica.donne_ev()
    tev = fltica.type_ev(ev)
    fltica.mise_a_jour()
    bouton.update(tev)
    if tev == 'Touche':
        print(tev)
