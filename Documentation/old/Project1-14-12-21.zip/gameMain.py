import locale
import fltica


settings={'sizex':800,'sizey':600,'lang':'eng' if "English" in locale.setlocale(locale.LC_ALL, '') else 'fr'
        ,'nb_object':20, 'maxMatch':5, 'misere':False, 'theme':'Minecraft'}
        
imagex, imagey = fltica.Image.open("images/allumette.png" if not(settings['theme'] == 'Minecraft') else 'images/redstone_torch_off.png').size
print(imagex, imagey)

class Player:
    def __init__(self, name, color):
        self.name = name
        self.matchDrawed = 0
        self.victory = 0
        self.nextPlay = False
        self.color = color
        self.numberSelected = 0

def playAnimation(anim):
    if anim == 'close':
        pass

def gameSettings():
    while True:
        fltica.mise_a_jour()

def getMltp():
    return (settings['sizex'])/settings['nb_object']/imagex

def selectMatch(listMatch, player, sizeMp):
    if (250 <= fltica.ordonnee_souris() <= 500) and (player.numberSelected < settings['maxMatch']):
        for i in range(len(listMatch)):
            if (len(listMatch[i]) == 2) and (listMatch[i][1]*sizeMp <= fltica.abscisse_souris() <= (listMatch[i][1]+imagex)*sizeMp):
                fltica.efface(listMatch[i][0])
                listMatch[i][0] = fltica.image(int(listMatch[i][1]*sizeMp), 250, int(imagex*sizeMp), int(imagey*sizeMp), "images/redstone_torch.png" if not(settings['theme'] == 'Minecraft') else 'images/redstone_torch.png', ancrage='nw')
                listMatch[i].append(0)
                player.numberSelected += 1


def unselectMatch(listMatch,player,sizeMp):
    if (250 <= fltica.ordonnee_souris() <= 500) and (player.numberSelected > 0):
        for i in range(len(listMatch)):
            if listMatch[i][1]*sizeMp <= fltica.abscisse_souris() <= (listMatch[i][1]+imagex)*sizeMp:
                if len(listMatch[i]) == 3:
                    fltica.efface(listMatch[i].pop())
                    fltica.efface(listMatch[i].pop(0))
                    print(listMatch[i])
                    listMatch[i].insert(0,fltica.image(int(listMatch[i][0]*sizeMp), 250, int(imagex*sizeMp), int(imagey*sizeMp), "images/allumette.png" if not(settings['theme'] == 'Minecraft') else 'images/redstone_torch_off.png', ancrage='nw'))
                    player.numberSelected -= 1


def drawMatch(listMatch, playerList):
    if playerList[0].numberSelected or playerList[1].numberSelected:
        toPop = []
        for i in range(len(listMatch)):
            if len(listMatch[i]) == 3:
                fltica.efface(listMatch[i][0])
                toPop.append(i)
        for i in toPop[::-1]:
            listMatch.pop(i)
        fltica.efface('name')
        if settings['theme'] == 'Minecraft':
            fltica.animated_image(settings['sizex']//2, settings['sizey']//2, 800, 600, 'images/explosion.gif')
        if playerList[0].nextPlay :
            fltica.texte(100, 100, playerList[1].name, tag='name', couleur=playerList[1].color)
            playerList[0].matchDrawed += len(toPop)
            playerList[0].nextPlay=False
            playerList[0].numberSelected=0
            playerList[1].nextPlay=True
        else:
            fltica.texte(100, 100, playerList[0].name, tag='name', couleur=playerList[0].color)
            playerList[1].matchDrawed += len(toPop)
            playerList[1].nextPlay=False
            playerList[1].numberSelected=0
            playerList[0].nextPlay=True
                





def game():
    fltica.efface_tout()

    player1 = Player("Louis", "Blue")
    player1.nextPlay = True
    player2 = Player("Martin", "Green")

    sizeMultiplier = getMltp()

    while True:
        fltica.texte(100, 100, player1.name if player1.nextPlay else player2.name, tag='name', couleur=player1.color if player1.nextPlay else player2.color)
        listMatch = []
        for i in range(settings['nb_object']):
            
            listMatch.append([fltica.image(int((imagex*i)*sizeMultiplier), 250, int(imagex*sizeMultiplier), int(imagey*sizeMultiplier), "images/allumette.png" if not(settings['theme'] == 'Minecraft') else 'images/redstone_torch_off.png', ancrage='nw'), imagex*i])

        while len(listMatch) > 0:
            ev = fltica.donne_ev()
            tev = fltica.type_ev(ev)
            if tev == 'ClicGauche':
                selectMatch(listMatch, player1, sizeMultiplier) if player1.nextPlay else selectMatch(listMatch, player2, sizeMultiplier)
            if tev == 'ClicDroit':
                print(listMatch)
                unselectMatch(listMatch, player1, sizeMultiplier) if player1.nextPlay else unselectMatch(listMatch, player2, sizeMultiplier)
                print(listMatch)
            if tev == 'Touche':
                if fltica.touche(ev) == 'space':
                    drawMatch(listMatch, [player1,player2])
            fltica.mise_a_jour()
            if tev == 'Quitte':
                exit()
        fltica.efface_tout()
        if settings['misere']:
            if player1.nextPlay:
                player1.nextPlay = False
                player2.nextPlay = True
            else:
                player1.nextPlay = True
                player2.nextPlay = False
        if player1.nextPlay: player1.victory += 1 
        else: player2.victory += 1
        fltica.texte(settings['sizex']//2, settings['sizey']//4, player1.name if player1.nextPlay else player2.name + " a gagné!", couleur=player1.color if player1.nextPlay else player2.color, ancrage="center")
        fltica.texte(settings['sizex']//2, settings['sizey']//2, "Victoires pour " +player1.name + ' : ' + str(player1.victory), couleur=player1.color, ancrage="center")
        fltica.texte(settings['sizex']//2, settings['sizey']//1.75, "Victoires pour " +player2.name + ' : ' + str(player2.victory), couleur=player2.color, ancrage="center")
        fltica.texte(settings['sizex']//2, settings['sizey']//1.5, "Cliquez pour recommencer", ancrage="center")
        if settings['misere']:
            if player1.nextPlay:
                player1.nextPlay = False
                player2.nextPlay = True
            else:
                player1.nextPlay = True
                player2.nextPlay = False
        fltica.attend_ev()
        fltica.efface_tout()
    
    

        


