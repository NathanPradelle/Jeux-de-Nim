from gameMain import game, settings, fltica



global text
text={
    
}


class Button:
    def __init__(self, posx, posy, text, lenght, function, font="Helvetica", size=24):
        """
        Makes a button using position, text and lenght of the text
        uses the class unique object identifier
        """
        self.isHovered = False
        self.posx, self.posy, self.text, self.font, self.size = posx, posy, text, font, size
        self.func = function
        self.lenght = lenght+15
        self.pulse = 0
        self.pulseBigger = True
        fltica.texte(self.posx, self.posy, self.text, ancrage='center', police=self.font, taille=self.size, tag='a'+str(id(self)))
        
    def update(self, tev):
        if ((fltica.abscisse_souris() < self.posx+self.lenght and fltica.abscisse_souris() > self.posx-self.lenght) and 
        (fltica.ordonnee_souris() < self.posy+40 and fltica.ordonnee_souris() > self.posy-10)):

            if tev == 'ClicGauche':
                self.func()
            self.isHovered = True
            fltica.efface('a'+str(id(self)))
            fltica.texte(self.posx, self.posy, self.text,'red' ,ancrage='center', police=self.font, taille=self.size+self.pulse, tag='a'+str(id(self))) # 'a'+ is requiered for fltk 
            if self.pulseBigger :
                self.pulse += 1
                if self.pulse == 6:
                    self.pulseBigger = False
            else:
                self.pulse -= 1
                if self.pulse == 0:
                    self.pulseBigger = True

        elif self.isHovered:
            self.isHovered = False
            fltica.efface('a'+str(id(self)))
            fltica.texte(self.posx, self.posy, self.text,ancrage='center', police=self.font, taille=self.size, tag='a'+str(id(self)))

def settingsMenu():
    print("Bonjour")

def mainMenu():
    fltica.cree_fenetre(settings['sizex'],settings['sizey'])
    fltica.__canevas.root.title('Jeux de Nim')
    fltica.animated_image(0, 0, 600, 338,  'images/explosion.gif', ancrage='nw')
    fltica.texte(settings['sizex']/2, settings['sizey']/8, "Jeux de Nim", ancrage='center', police='Comic Sans MS', couleur='blue', taille = 50)
    buttonList = []
    buttonList.append(Button(20+40, settings['sizey']/1.68, 'Jouer', 30, game)) 
    buttonList.append(Button(20+80, settings['sizey']/1.43, 'Paramètres', 80, settingsMenu)) 
    buttonList.append(Button(20+45, settings['sizey']/1.23, 'Quitter', 50, exit)) 

    while True:
        ev = fltica.donne_ev()
        tev = fltica.type_ev(ev)
        for elem in buttonList : elem.update(tev)
        fltica.mise_a_jour()
        if tev == 'Touche' or tev == 'Quitte':
            if fltica.touche_pressee('Escape') or tev == 'Quitte':
                exit()



mainMenu()